import { Component, OnInit } from '@angular/core';
import { ContatosService } from '../contatos.service';

@Component({
  selector: 'app-contatos',
  templateUrl: './contatos.component.html',
  styleUrls: ['./contatos.component.scss'] // Atualize aqui para SCSS
})
export class ContatosComponent implements OnInit {
  contatos: { id: number; nome: string; telefone: string }[] = [];

  constructor(private contatosService: ContatosService) { }

  ngOnInit(): void {
    this.contatos = this.contatosService.getContatos();
  }
}
