import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContatosComponent } from './contatos/contatos.component';

const routes: Routes = [
  { path: 'contatos', component: ContatosComponent },
  { path: '', redirectTo: '/contatos', pathMatch: 'full' },
  { path: '**', redirectTo: '/contatos' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
