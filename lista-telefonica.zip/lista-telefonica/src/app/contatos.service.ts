import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ContatosService {
  private contatos = [
    { id: 1, nome: 'João Silva', telefone: '(11) 99999-9999' },
    { id: 2, nome: 'Maria Oliveira', telefone: '(21) 98888-8888' },
    { id: 3, nome: 'Carlos Souza', telefone: '(31) 97777-7777' },
    { id: 4, nome: 'Gustavo Farias', telefone: '(45) 99128-1167'}
  ];

  constructor() { }

  getContatos() {
    return this.contatos;
  }
}
